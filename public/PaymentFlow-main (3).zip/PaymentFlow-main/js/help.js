// Help & Support Page JavaScript

// FAQ Data
const faqData = [
    {
        question: "Comment configurer les rappels de paiement automatiques ?",
        answer: "Pour configurer les rappels de paiement automatiques, accédez à Créances > menu ... sur la créance à rappeler > Paramètres de relance. Vous pourrez y définir les dates et les contenus de vos rappels.",
        category: "features"
    },
    {
        question: "Qu'est-ce qu'un profil de rappel ?",
        answer: "Un profil de rappel permet de définir automatiquement les dates de relance en fonction de la première relance. Pour les créer, allez dans Paramètres > Paramètres d'envoi de relances > Configuration des profils. Vous pouvez définir les délais entre les relances automatiques.",
        category: "features"
    },
    {
        question: "Comment fonctionne le rapport de balance âgée des comptes clients ?",
        answer: "Le rapport de balance âgée classe vos factures impayées par ancienneté (0-30 jours, 31-60 jours, 61-90 jours et 90+ jours). Cela vous aide à identifier les factures en retard et à prioriser vos efforts de recouvrement. Vous pouvez accéder à ce rapport depuis le menu Tableau de bord",
        category: "features"
    },
    {
        question: "Puis-je intégrer mes données comptables dans Payment-Flow ?",
        answer: "Oui, vous pouvez effectuer l'intégration comptable en important les données via un fichier CSV ou par saisie manuelle.",
        category: "technical"
    },
    {
        question: "Comment mettre à jour mes informations de facturation ?",
        answer: "Pour mettre à jour vos informations de facturation, allez dans Paramètres > Paramètres de facturation. Vous pouvez y mettre à jour vos informations de paiement (Adresse, Entreprise, SIRET)",
        category: "billing"
    },
    {
        question: "Puis-je ajouter des membres à mon équipe ?",
        answer: "Oui, vous pouvez ajouter des membres à votre compte Payment-Flow. Allez dans Paramètres > Gestion des membres > Ajouter un membre pour inviter des collègues.",
        category: "account"
    },
    {
        question: "Que faire si j'oublie mon mot de passe ?",
        answer: "Si vous oubliez votre mot de passe, cliquez sur le lien 'Mot de passe oublié' sur la page de connexion. Saisissez votre adresse e-mail, et nous vous enverrons un lien de réinitialisation. Pour des raisons de sécurité, le lien expirera après 24 heures. Si vous ne recevez pas l'e-mail, vérifiez votre dossier spam ou contactez notre équipe support.",
        category: "account"
    }
];

// Global variables
let currentFilter = 'all';
let openFaqItems = new Set();

// Initialize page when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeFaqSection();
    initializeSearchFunctionality();
    initializeContactForm();
    initializeSupportOptions();
});

// FAQ Section Functions
function initializeFaqSection() {
    renderFaqItems();
    setupFaqEventListeners();
}

function renderFaqItems() {
    const container = document.getElementById('faqContainer');
    if (!container) return;

    const filteredFaqs = currentFilter === 'all' 
        ? faqData 
        : faqData.filter(item => item.category === currentFilter);

    container.innerHTML = filteredFaqs.map((faq, index) => `
        <div class="faq-item fade-in" data-category="${faq.category}">
            <button class="faq-question" onclick="toggleFaqItem(${index})">
                <div class="d-flex align-items-center">
                    <span class="fw-medium text-gray-900">${faq.question}</span>
                    <span class="faq-category-badge">${faq.category}</span>
                </div>
                <div class="text-blue-600">
                    ${openFaqItems.has(index) ? 
                        '<svg style="width: 20px; height: 20px;" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line></svg>' :
                        '<svg style="width: 20px; height: 20px;" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>'
                    }
                </div>
            </button>
            <div class="faq-answer slide-down" style="display: ${openFaqItems.has(index) ? 'block' : 'none'};">
                <p>${faq.answer}</p>
            </div>
        </div>
    `).join('');
}

function toggleFaqItem(index) {
    if (openFaqItems.has(index)) {
        openFaqItems.delete(index);
    } else {
        openFaqItems.add(index);
    }
    renderFaqItems();
}

function filterFaq(category) {
    currentFilter = category;
    
    // Update filter buttons
    document.querySelectorAll('[id^="filter-"]').forEach(btn => {
        btn.classList.remove('bg-blue-600', 'text-white');
        btn.classList.add('bg-gray-100', 'text-gray-700');
    });
    
    const activeBtn = document.getElementById(`filter-${category}`);
    if (activeBtn) {
        activeBtn.classList.remove('bg-gray-100', 'text-gray-700');
        activeBtn.classList.add('bg-blue-600', 'text-white');
    }
    
    // Clear open items and re-render
    openFaqItems.clear();
    renderFaqItems();
}

function setupFaqEventListeners() {
    // Smooth scroll to FAQ section when clicking "Need more help" button
    document.querySelectorAll('a[href="#contact"]').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const contactSection = document.getElementById('contact');
            if (contactSection) {
                contactSection.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
}

// Search Functionality
function initializeSearchFunctionality() {
    const searchInput = document.querySelector('input[placeholder="Rechercher des réponses..."]');
    const searchButton = document.querySelector('.search-button');
    
    if (searchInput) {
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                performSearch();
            }
        });
    }
    
    if (searchButton) {
        searchButton.addEventListener('click', performSearch);
    }
    
    // Popular search tags
    document.querySelectorAll('.popular-search-tag').forEach(tag => {
        tag.addEventListener('click', function(e) {
            e.preventDefault();
            if (searchInput) {
                searchInput.value = this.textContent.trim();
                performSearch();
            }
        });
    });
}

function performSearch() {
    const searchInput = document.querySelector('input[placeholder="Rechercher des réponses..."]');
    const query = searchInput ? searchInput.value.trim().toLowerCase() : '';
    
    if (!query) return;
    
    // Filter FAQ items based on search query
    const filteredFaqs = faqData.filter(faq => 
        faq.question.toLowerCase().includes(query) || 
        faq.answer.toLowerCase().includes(query)
    );
    
    // Update current filter to show all and render filtered results
    currentFilter = 'all';
    document.querySelectorAll('[id^="filter-"]').forEach(btn => {
        btn.classList.remove('bg-blue-600', 'text-white');
        btn.classList.add('bg-gray-100', 'text-gray-700');
    });
    
    const allBtn = document.getElementById('filter-all');
    if (allBtn) {
        allBtn.classList.remove('bg-gray-100', 'text-gray-700');
        allBtn.classList.add('bg-blue-600', 'text-white');
    }
    
    // Temporarily replace faqData for rendering
    const originalData = [...faqData];
    faqData.splice(0, faqData.length, ...filteredFaqs);
    
    openFaqItems.clear();
    renderFaqItems();
    
    // Restore original data
    faqData.splice(0, faqData.length, ...originalData);
    
    // Scroll to FAQ section
    const faqSection = document.getElementById('faq');
    if (faqSection) {
        faqSection.scrollIntoView({ behavior: 'smooth' });
    }
}

// Contact Form Functions
function initializeContactForm() {
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', handleContactSubmit);
    }
    
    // Close modal when clicking outside
    const modalOverlay = document.getElementById('contactModalOverlay');
    if (modalOverlay) {
        modalOverlay.addEventListener('click', function(e) {
            if (e.target === modalOverlay) {
                closeContactModal();
            }
        });
    }
    
    // Close modal with ESC key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeContactModal();
        }
    });
}

function handleContactSubmit(event) {
    event.preventDefault();
    
    const formData = new FormData(event.target);
    const data = {
        name: formData.get('name'),
        email: formData.get('email'),
        subject: formData.get('subject'),
        message: formData.get('message'),
        privacy: formData.get('privacy')
    };
    
    // Validate form
    if (!validateContactForm(data)) {
        return;
    }
    
    // Show loading state
    setContactLoadingState(true);
    
    // Simulate form submission
    setTimeout(() => {
        console.log('Contact form submitted:', data);
        showContactSuccess();
        setContactLoadingState(false);
    }, 1000);
}

function validateContactForm(data) {
    const errorDiv = document.getElementById('contactError');
    const errorMessage = document.getElementById('contactErrorMessage');
    
    if (!data.name || data.name.trim().length < 2) {
        showContactError('Le nom doit contenir au moins 2 caractères.');
        return false;
    }
    
    if (!data.email || !isValidEmail(data.email)) {
        showContactError('Veuillez entrer une adresse email valide.');
        return false;
    }
    
    if (!data.subject) {
        showContactError('Veuillez sélectionner un sujet.');
        return false;
    }
    
    if (!data.message || data.message.trim().length < 10) {
        showContactError('Le message doit contenir au moins 10 caractères.');
        return false;
    }
    
    if (!data.privacy) {
        showContactError('Vous devez accepter la politique de confidentialité.');
        return false;
    }
    
    hideContactError();
    return true;
}

function showContactError(message) {
    const errorDiv = document.getElementById('contactError');
    const errorMessage = document.getElementById('contactErrorMessage');
    
    if (errorDiv && errorMessage) {
        errorMessage.textContent = message;
        errorDiv.style.display = 'flex';
    }
}

function hideContactError() {
    const errorDiv = document.getElementById('contactError');
    if (errorDiv) {
        errorDiv.style.display = 'none';
    }
}

function showContactSuccess() {
    const successDiv = document.getElementById('contactSuccess');
    const formDiv = document.getElementById('contactForm');
    
    if (successDiv && formDiv) {
        formDiv.style.display = 'none';
        successDiv.style.display = 'block';
    }
}

function setContactLoadingState(loading) {
    const submitBtn = document.getElementById('contactSubmitBtn');
    const spinner = document.getElementById('contactSubmitSpinner');
    const text = document.getElementById('contactSubmitText');
    
    if (submitBtn && spinner && text) {
        if (loading) {
            submitBtn.disabled = true;
            spinner.style.display = 'block';
            text.textContent = 'Envoi en cours...';
        } else {
            submitBtn.disabled = false;
            spinner.style.display = 'none';
            text.textContent = 'Envoyer le message';
        }
    }
}

function resetContactForm() {
    const successDiv = document.getElementById('contactSuccess');
    const formDiv = document.getElementById('contactForm');
    const form = document.getElementById('contactForm');
    
    if (successDiv && formDiv && form) {
        successDiv.style.display = 'none';
        formDiv.style.display = 'block';
        form.reset();
        hideContactError();
    }
}

function closeContactModal() {
    const modalOverlay = document.getElementById('contactModalOverlay');
    if (modalOverlay) {
        modalOverlay.style.display = 'none';
    }
}

// Support Options Functions
function initializeSupportOptions() {
    // Chat functionality
    window.openChat = function() {
        if (window.Chatling && typeof window.Chatling.open === "function") {
            window.Chatling.open();
        } else {
            console.warn("Chatling n'est pas encore chargé.");
            // Fallback: show contact modal
            showContactModal();
        }
    };
}

// Support Form Functions (separate from contact modal)
function handleSupportSubmit(event) {
    event.preventDefault();
    
    const formData = new FormData(event.target);
    const data = {
        name: formData.get('name'),
        email: formData.get('email'),
        subject: formData.get('subject'),
        message: formData.get('message')
    };
    
    // Validate form
    if (!validateSupportForm(data)) {
        return;
    }
    
    // Show loading state
    setSupportLoadingState(true);
    
    // Simulate form submission
    setTimeout(() => {
        console.log('Support form submitted:', data);
        showSupportSuccess();
        setSupportLoadingState(false);
    }, 1000);
}

function validateSupportForm(data) {
    if (!data.name || data.name.trim().length < 2) {
        alert('Le nom doit contenir au moins 2 caractères.');
        return false;
    }
    
    if (!data.email || !isValidEmail(data.email)) {
        alert('Veuillez entrer une adresse email valide.');
        return false;
    }
    
    if (!data.subject) {
        alert('Veuillez sélectionner un sujet.');
        return false;
    }
    
    if (!data.message || data.message.trim().length < 10) {
        alert('Le message doit contenir au moins 10 caractères.');
        return false;
    }
    
    return true;
}

function showSupportSuccess() {
    const successDiv = document.getElementById('contactSuccess');
    const formDiv = document.querySelector('#contact form');
    
    if (successDiv && formDiv) {
        formDiv.style.display = 'none';
        successDiv.style.display = 'block';
    }
}

function setSupportLoadingState(loading) {
    const submitBtn = document.querySelector('#contact button[type="submit"]');
    
    if (submitBtn) {
        if (loading) {
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<svg class="w-5 h-5 animate-spin mr-2" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>Envoi en cours...';
        } else {
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<svg style="width: 16px; height: 16px; margin-right: 8px;" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22,2 15,22 11,13 2,9 22,2"></polygon></svg>Envoyer le message';
        }
    }
}

// Utility Functions
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function showContactModal() {
    const modalOverlay = document.getElementById('contactModalOverlay');
    if (modalOverlay) {
        modalOverlay.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }
}

function showPrivacyPolicy() {
    const modalOverlay = document.getElementById('privacyModalOverlay');
    if (modalOverlay) {
        modalOverlay.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }
}

function hidePrivacyPolicy() {
    const modalOverlay = document.getElementById('privacyModalOverlay');
    if (modalOverlay) {
        modalOverlay.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
}

// Navigation Functions (from script.js)
function navigateTo(path) {
    window.location.href = path;
}

function showFeaturesMenu() {
    const dropdown = document.getElementById('featuresDropdown');
    const arrow = document.getElementById('featuresArrow');
    
    if (dropdown && arrow) {
        dropdown.style.display = 'block';
        arrow.style.transform = 'rotate(180deg)';
    }
}

function hideFeaturesMenu() {
    const dropdown = document.getElementById('featuresDropdown');
    const arrow = document.getElementById('featuresArrow');
    
    if (dropdown && arrow) {
        dropdown.style.display = 'none';
        arrow.style.transform = 'rotate(0deg)';
    }
}

function showResourcesMenu() {
    const dropdown = document.getElementById('resourcesDropdown');
    const arrow = document.getElementById('resourcesArrow');
    
    if (dropdown && arrow) {
        dropdown.style.display = 'block';
        arrow.style.transform = 'rotate(180deg)';
    }
}

function hideResourcesMenu() {
    const dropdown = document.getElementById('resourcesDropdown');
    const arrow = document.getElementById('resourcesArrow');
    
    if (dropdown && arrow) {
        dropdown.style.display = 'none';
        arrow.style.transform = 'rotate(0deg)';
    }
}

function toggleMobileMenu() {
    const mobileMenu = document.getElementById('mobileMenu');
    const mobileMenuIcon = document.getElementById('mobileMenuIcon');
    
    if (mobileMenu && mobileMenuIcon) {
        const isOpen = mobileMenu.style.display === 'block';
        mobileMenu.style.display = isOpen ? 'none' : 'block';
        
        // Toggle icon between hamburger and X
        if (isOpen) {
            mobileMenuIcon.innerHTML = `
                <line x1="4" y1="6" x2="20" y2="6"/>
                <line x1="4" y1="12" x2="20" y2="12"/>
                <line x1="4" y1="18" x2="20" y2="18"/>
            `;
        } else {
            mobileMenuIcon.innerHTML = `
                <line x1="18" y1="6" x2="6" y2="18"/>
                <line x1="6" y1="6" x2="18" y2="18"/>
            `;
        }
    }
}

function toggleMobileFeaturesMenu() {
    const mobileMenu = document.getElementById('mobileFeaturesMenu');
    const mobileArrow = document.getElementById('mobileFeaturesArrow');
    
    if (mobileMenu && mobileArrow) {
        const isOpen = mobileMenu.style.display === 'block';
        mobileMenu.style.display = isOpen ? 'none' : 'block';
        mobileArrow.style.transform = isOpen ? 'rotate(0deg)' : 'rotate(180deg)';
    }
}

function toggleMobileResourcesMenu() {
    const mobileMenu = document.getElementById('mobileResourcesMenu');
    const mobileArrow = document.getElementById('mobileResourcesArrow');
    
    if (mobileMenu && mobileArrow) {
        const isOpen = mobileMenu.style.display === 'block';
        mobileMenu.style.display = isOpen ? 'none' : 'block';
        mobileArrow.style.transform = isOpen ? 'rotate(0deg)' : 'rotate(180deg)';
    }
}

// Close mobile menu when clicking outside
document.addEventListener('click', function(e) {
    const mobileMenu = document.getElementById('mobileMenu');
    const mobileMenuIcon = document.getElementById('mobileMenuIcon');
    
    if (mobileMenu && mobileMenuIcon && !mobileMenu.contains(e.target) && !mobileMenuIcon.contains(e.target)) {
        mobileMenu.style.display = 'none';
        if (mobileMenuIcon) {
            mobileMenuIcon.innerHTML = `
                <line x1="4" y1="6" x2="20" y2="6"/>
                <line x1="4" y1="12" x2="20" y2="12"/>
                <line x1="4" y1="18" x2="20" y2="18"/>
            `;
        }
    }
});

// Initialize Chatling if available
if (typeof window.Chatling !== 'undefined') {
    window.Chatling.init({
        // Chatling configuration
    });
}
