// PaymentFlow JavaScript

// DOM Content Loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

// Go Back Function for Testimonials Page
function goBack() {
    window.location.href = 'index.html';
}

// Initialize Application
function initializeApp() {
    initializeNavigation();
    initializeAnimations();
    initializeCarousels();
    initializeScrollEffects();
    initializeContactForm();
    initializeAnalytics();
    initializeAccessibility();
    initializeCRMFeatures();
}

// Navigation Functions
function initializeNavigation() {
    const navbar = document.querySelector('.navbar');
    const navLinks = document.querySelectorAll('.nav-link');
    
    // Navbar scroll effect
    window.addEventListener('scroll', function() {
        if (window.scrollY > 50) {
            navbar.classList.add('shadow');
        } else {
            navbar.classList.remove('shadow');
        }
    });
    
    // Smooth scroll for anchor links
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            if (href.startsWith('#')) {
                e.preventDefault();
                const target = document.querySelector(href);
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            }
        });
    });
    
    // Mobile menu close on link click
    const navbarToggler = document.querySelector('.navbar-toggler');
    const navbarCollapse = document.querySelector('.navbar-collapse');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            if (window.innerWidth < 992) {
                navbarCollapse.classList.remove('show');
            }
        });
    });
}

// Animation Functions
function initializeAnimations() {
    // Intersection Observer for animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-fade-in-up');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);
    
    // Observe elements for animation
    const animateElements = document.querySelectorAll('.feature-card, .card, .carousel-item');
    animateElements.forEach(el => {
        observer.observe(el);
    });
}

// Carousel Functions
function initializeCarousels() {
    // Auto-play carousels
    const carousels = document.querySelectorAll('.carousel');
    
    carousels.forEach(carousel => {
        const carouselInstance = new bootstrap.Carousel(carousel, {
            interval: 5000,
            wrap: true,
            touch: true
        });
        
        // Pause on hover
        carousel.addEventListener('mouseenter', function() {
            carouselInstance.pause();
        });
        
        carousel.addEventListener('mouseleave', function() {
            carouselInstance.cycle();
        });
    });
}

// Scroll Effects
function initializeScrollEffects() {
    // Parallax effect for hero section
    window.addEventListener('scroll', function() {
        const scrolled = window.pageYOffset;
        const heroSection = document.querySelector('.hero-section');
        
        if (heroSection) {
            const rate = scrolled * -0.5;
            heroSection.style.transform = `translateY(${rate}px)`;
        }
    });
    
    // Back to top button
    createBackToTopButton();
}

// Back to Top Button
function createBackToTopButton() {
    const backToTopBtn = document.createElement('button');
    backToTopBtn.innerHTML = `
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M18 15l-6-6-6 6"/>
        </svg>
    `;
    backToTopBtn.className = 'btn btn-primary position-fixed';
    backToTopBtn.style.cssText = `
        bottom: 20px;
        right: 20px;
        z-index: 1000;
        border-radius: 50%;
        width: 50px;
        height: 50px;
        display: none;
        box-shadow: 0 4px 12px rgba(37, 99, 235, 0.3);
    `;
    
    document.body.appendChild(backToTopBtn);
    
    // Show/hide button based on scroll position
    window.addEventListener('scroll', function() {
        if (window.pageYOffset > 300) {
            backToTopBtn.style.display = 'block';
        } else {
            backToTopBtn.style.display = 'none';
        }
    });
    
    // Scroll to top on click
    backToTopBtn.addEventListener('click', function() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
}

// Contact Form Functions
function initializeContactForm() {
    const contactForms = document.querySelectorAll('form[data-contact-form]');
    
    contactForms.forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            handleContactFormSubmission(this);
        });
    });
}

// Handle Contact Form Submission
function handleContactFormSubmission(form) {
    const formData = new FormData(form);
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    
    // Show loading state
    submitBtn.textContent = 'Envoi en cours...';
    submitBtn.disabled = true;
    form.classList.add('loading');
    
    // Simulate form submission (replace with actual API call)
    setTimeout(() => {
        // Reset form
        form.reset();
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
        form.classList.remove('loading');
        
        // Show success message
        showNotification('Message envoyé avec succès !', 'success');
        
        // Track form submission
        if (typeof gtag !== 'undefined') {
            gtag('event', 'form_submit', {
                event_category: 'engagement',
                event_label: 'contact_form'
            });
        }
    }, 2000);
}

// Notification System
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} position-fixed`;
    notification.style.cssText = `
        top: 20px;
        right: 20px;
        z-index: 1050;
        min-width: 300px;
        animation: slideInRight 0.3s ease-out;
    `;
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" onclick="this.parentElement.remove()"></button>
    `;
    
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 5000);
}

// Analytics Functions
function initializeAnalytics() {
    // Track page views
    if (typeof gtag !== 'undefined') {
        gtag('event', 'page_view', {
            page_title: document.title,
            page_location: window.location.href
        });
    }
    
    // Track button clicks
    const buttons = document.querySelectorAll('button, .btn');
    buttons.forEach(button => {
        button.addEventListener('click', function() {
            const buttonText = this.textContent.trim();
            const buttonClass = this.className;
            
            if (typeof gtag !== 'undefined') {
                gtag('event', 'click', {
                    event_category: 'engagement',
                    event_label: buttonText,
                    value: buttonClass.includes('primary') ? 1 : 0
                });
            }
        });
    });
    
    // Track scroll depth
    let maxScroll = 0;
    window.addEventListener('scroll', function() {
        const scrollPercent = Math.round((window.scrollY / (document.body.scrollHeight - window.innerHeight)) * 100);
        
        if (scrollPercent > maxScroll && scrollPercent % 25 === 0) {
            maxScroll = scrollPercent;
            
            if (typeof gtag !== 'undefined') {
                gtag('event', 'scroll', {
                    event_category: 'engagement',
                    event_label: `${scrollPercent}%`,
                    value: scrollPercent
                });
            }
        }
    });
}

// Accessibility Functions
function initializeAccessibility() {
    // Skip to main content link
    const skipLink = document.createElement('a');
    skipLink.href = '#main-content';
    skipLink.textContent = 'Aller au contenu principal';
    skipLink.className = 'sr-only sr-only-focusable btn btn-primary';
    skipLink.style.cssText = `
        position: absolute;
        top: 10px;
        left: 10px;
        z-index: 1001;
    `;
    
    document.body.insertBefore(skipLink, document.body.firstChild);
    
    // Add main content ID
    const mainContent = document.querySelector('main') || document.querySelector('.hero-section');
    if (mainContent) {
        mainContent.id = 'main-content';
    }
    
    // Keyboard navigation for carousels
    const carousels = document.querySelectorAll('.carousel');
    carousels.forEach(carousel => {
        const prevBtn = carousel.querySelector('.carousel-control-prev');
        const nextBtn = carousel.querySelector('.carousel-control-next');
        
        if (prevBtn && nextBtn) {
            prevBtn.setAttribute('tabindex', '0');
            nextBtn.setAttribute('tabindex', '0');
            
            [prevBtn, nextBtn].forEach(btn => {
                btn.addEventListener('keydown', function(e) {
                    if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        this.click();
                    }
                });
            });
        }
    });
    
    // Focus management for modals
    document.addEventListener('shown.bs.modal', function(e) {
        const modal = e.target;
        const focusableElements = modal.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
        if (focusableElements.length > 0) {
            focusableElements[0].focus();
        }
    });
}

// Utility Functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// Error Handling
window.addEventListener('error', function(e) {
    console.error('Global error:', e.error);
    
    if (typeof gtag !== 'undefined') {
        gtag('event', 'exception', {
            description: e.error?.message || 'Unknown error',
            fatal: false
        });
    }
});

window.addEventListener('unhandledrejection', function(e) {
    console.error('Unhandled promise rejection:', e.reason);
    
    if (typeof gtag !== 'undefined') {
        gtag('event', 'exception', {
            description: e.reason?.message || 'Unhandled promise rejection',
            fatal: false
        });
    }
});

// Performance Monitoring
window.addEventListener('load', function() {
    // Measure page load time
    const loadTime = performance.now();
    
    if (typeof gtag !== 'undefined') {
        gtag('event', 'timing_complete', {
            name: 'load',
            value: Math.round(loadTime)
        });
    }
});

// Service Worker Registration (for PWA features)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
        navigator.serviceWorker.register('/sw.js')
            .then(function(registration) {
                console.log('ServiceWorker registration successful');
            })
            .catch(function(err) {
                console.log('ServiceWorker registration failed');
            });
    });
}

// Testimonial Carousel Functions
let currentTestimonialIndex = 0;
const totalTestimonials = 6;
const testimonialsPerView = 3;

function initializeTestimonialCarousel() {
    updateTestimonialDisplay();
}

function nextTestimonial() {
    if (currentTestimonialIndex < totalTestimonials - testimonialsPerView) {
        currentTestimonialIndex++;
    } else {
        currentTestimonialIndex = 0;
    }
    updateTestimonialDisplay();
}

function previousTestimonial() {
    if (currentTestimonialIndex > 0) {
        currentTestimonialIndex--;
    } else {
        currentTestimonialIndex = totalTestimonials - testimonialsPerView;
    }
    updateTestimonialDisplay();
}

function goToTestimonial(index) {
    currentTestimonialIndex = index;
    updateTestimonialDisplay();
}

function updateTestimonialDisplay() {
    const slider = document.getElementById('testimonialsSlider');
    const dots = document.querySelectorAll('.testimonial-dot');
    
    if (slider) {
        const slideWidth = 100 / testimonialsPerView;
        const translateX = -(currentTestimonialIndex * slideWidth);
        slider.style.transform = `translateX(${translateX}%)`;
    }
    
    // Update dots
    dots.forEach((dot, index) => {
        dot.classList.remove('active');
        if (index === Math.floor(currentTestimonialIndex / testimonialsPerView)) {
            dot.classList.add('active');
        }
    });
}

// Auto-play testimonials
function startTestimonialAutoPlay() {
    setInterval(() => {
        nextTestimonial();
    }, 5000);
}

// Initialize testimonial carousel when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeTestimonialCarousel();
    startTestimonialAutoPlay();
});

// Reset Cache Function - matches original functionality
function resetCache() {
    localStorage.clear();
    sessionStorage.clear();
    window.location.reload();
}

// Use Cases Carousel - Desktop
let currentUseCaseIndex = 0;
const totalUseCases = 3;

function nextUseCase() {
    currentUseCaseIndex = (currentUseCaseIndex + 1) % totalUseCases;
    updateUseCaseDisplay();
}

function previousUseCase() {
    currentUseCaseIndex = (currentUseCaseIndex - 1 + totalUseCases) % totalUseCases;
    updateUseCaseDisplay();
}

function updateUseCaseDisplay() {
    // Hide all slides
    for (let i = 1; i <= totalUseCases; i++) {
        const slide = document.getElementById(`useCaseSlide${i}`);
        if (slide) {
            slide.classList.add('d-none');
            slide.classList.remove('d-block');
        }
    }
    
    // Show current slide
    const currentSlide = document.getElementById(`useCaseSlide${currentUseCaseIndex + 1}`);
    if (currentSlide) {
        currentSlide.classList.remove('d-none');
        currentSlide.classList.add('d-block');
    }
    
    // Update pagination
    updateUseCasePagination();
}

function updateUseCasePagination() {
    const pagination = document.querySelector('.use-case-pagination');
    if (pagination) {
        pagination.innerHTML = '';
        for (let i = 0; i < totalUseCases; i++) {
            const dot = document.createElement('span');
            dot.className = `swiper-pagination-bullet ${i === currentUseCaseIndex ? 'swiper-pagination-bullet-active' : ''}`;
            dot.onclick = () => {
                currentUseCaseIndex = i;
                updateUseCaseDisplay();
            };
            pagination.appendChild(dot);
        }
    }
}

// Use Cases Carousel - Mobile
let currentMobileUseCaseIndex = 0;

function nextMobileUseCase() {
    currentMobileUseCaseIndex = (currentMobileUseCaseIndex + 1) % totalUseCases;
    updateMobileUseCaseDisplay();
}

function previousMobileUseCase() {
    currentMobileUseCaseIndex = (currentMobileUseCaseIndex - 1 + totalUseCases) % totalUseCases;
    updateMobileUseCaseDisplay();
}

function updateMobileUseCaseDisplay() {
    // Hide all slides
    for (let i = 1; i <= totalUseCases; i++) {
        const slide = document.getElementById(`mobileUseCaseSlide${i}`);
        if (slide) {
            slide.classList.add('d-none');
            slide.classList.remove('d-block');
        }
    }
    
    // Show current slide
    const currentSlide = document.getElementById(`mobileUseCaseSlide${currentMobileUseCaseIndex + 1}`);
    if (currentSlide) {
        currentSlide.classList.remove('d-none');
        currentSlide.classList.add('d-block');
    }
    
    // Update pagination
    updateMobileUseCasePagination();
}

function updateMobileUseCasePagination() {
    const pagination = document.querySelector('.mobile-use-case-pagination');
    if (pagination) {
        pagination.innerHTML = '';
        for (let i = 0; i < totalUseCases; i++) {
            const dot = document.createElement('span');
            dot.className = `swiper-pagination-bullet ${i === currentMobileUseCaseIndex ? 'swiper-pagination-bullet-active' : ''}`;
            dot.onclick = () => {
                currentMobileUseCaseIndex = i;
                updateMobileUseCaseDisplay();
            };
            pagination.appendChild(dot);
        }
    }
}

// Initialize Use Cases carousels
document.addEventListener('DOMContentLoaded', function() {
    updateUseCaseDisplay();
    updateMobileUseCaseDisplay();
    initializeAnimatedIcons();
});

// Animated Resource Icons
function initializeAnimatedIcons() {
    const animatedIcons = document.querySelectorAll('.animated-resource-icon');
    
    animatedIcons.forEach(icon => {
        icon.addEventListener('click', function(e) {
            e.stopPropagation();
            
            // Remove any existing animation classes
            this.classList.remove('bounce', 'spin', 'pulse');
            
            // Add appropriate animation based on icon type
            const svg = this.querySelector('svg');
            if (svg) {
                const color = this.style.color;
                if (color === 'rgb(37, 99, 235)' || color === '#2563eb') {
                    // Témoignages - bounce
                    this.classList.add('bounce');
                } else if (color === 'rgb(34, 211, 238)' || color === '#22d3ee') {
                    // Blog - spin
                    this.classList.add('spin');
                } else if (color === 'rgb(250, 204, 21)' || color === '#facc15') {
                    // Guides - pulse
                    this.classList.add('pulse');
                }
            }
            
            // Remove animation class after animation completes
            setTimeout(() => {
                this.classList.remove('bounce', 'spin', 'pulse');
            }, 1000);
        });
    });
}

// Navigation Dropdown Functions
let isFeaturesMenuOpen = false;
let isResourcesMenuOpen = false;
let isMobileMenuOpen = false;
let isMobileFeaturesMenuOpen = false;
let isMobileResourcesMenuOpen = false;

function showFeaturesMenu() {
    isFeaturesMenuOpen = true;
    isResourcesMenuOpen = false;
    document.getElementById('featuresDropdown').classList.add('show');
    document.getElementById('resourcesDropdown').classList.remove('show');
    document.getElementById('featuresArrow').classList.add('rotate-180');
    document.getElementById('resourcesArrow').classList.remove('rotate-180');
}

function hideFeaturesMenu() {
    isFeaturesMenuOpen = false;
    document.getElementById('featuresDropdown').classList.remove('show');
    document.getElementById('featuresArrow').classList.remove('rotate-180');
}

function showResourcesMenu() {
    isResourcesMenuOpen = true;
    isFeaturesMenuOpen = false;
    document.getElementById('resourcesDropdown').classList.add('show');
    document.getElementById('featuresDropdown').classList.remove('show');
    document.getElementById('resourcesArrow').classList.add('rotate-180');
    document.getElementById('featuresArrow').classList.remove('rotate-180');
}

function hideResourcesMenu() {
    isResourcesMenuOpen = false;
    document.getElementById('resourcesDropdown').classList.remove('show');
    document.getElementById('resourcesArrow').classList.remove('rotate-180');
}

function toggleMobileMenu() {
    isMobileMenuOpen = !isMobileMenuOpen;
    const mobileMenu = document.getElementById('mobileMenu');
    const mobileMenuIcon = document.getElementById('mobileMenuIcon');
    
    if (isMobileMenuOpen) {
        mobileMenu.classList.add('show');
        // Change to X icon
        mobileMenuIcon.innerHTML = `
            <line x1="18" y1="6" x2="6" y2="18"/>
            <line x1="6" y1="6" x2="18" y2="18"/>
        `;
    } else {
        mobileMenu.classList.remove('show');
        // Change back to hamburger icon
        mobileMenuIcon.innerHTML = `
            <line x1="4" y1="6" x2="20" y2="6"/>
            <line x1="4" y1="12" x2="20" y2="12"/>
            <line x1="4" y1="18" x2="20" y2="18"/>
        `;
        // Close submenus
        hideMobileFeaturesMenu();
        hideMobileResourcesMenu();
    }
}

function toggleMobileFeaturesMenu() {
    isMobileFeaturesMenuOpen = !isMobileFeaturesMenuOpen;
    if (isMobileFeaturesMenuOpen) {
        isMobileResourcesMenuOpen = false;
    }
    updateMobileMenus();
}

function toggleMobileResourcesMenu() {
    isMobileResourcesMenuOpen = !isMobileResourcesMenuOpen;
    if (isMobileResourcesMenuOpen) {
        isMobileFeaturesMenuOpen = false;
    }
    updateMobileMenus();
}

function hideMobileFeaturesMenu() {
    isMobileFeaturesMenuOpen = false;
    updateMobileMenus();
}

function hideMobileResourcesMenu() {
    isMobileResourcesMenuOpen = false;
    updateMobileMenus();
}

function updateMobileMenus() {
    const featuresMenu = document.getElementById('mobileFeaturesMenu');
    const resourcesMenu = document.getElementById('mobileResourcesMenu');
    const featuresArrow = document.getElementById('mobileFeaturesArrow');
    const resourcesArrow = document.getElementById('mobileResourcesArrow');
    
    if (featuresMenu) {
        if (isMobileFeaturesMenuOpen) {
            featuresMenu.classList.add('show');
            featuresArrow.classList.add('rotate-180');
        } else {
            featuresMenu.classList.remove('show');
            featuresArrow.classList.remove('rotate-180');
        }
    }
    
    if (resourcesMenu) {
        if (isMobileResourcesMenuOpen) {
            resourcesMenu.classList.add('show');
            resourcesArrow.classList.add('rotate-180');
        } else {
            resourcesMenu.classList.remove('show');
            resourcesArrow.classList.remove('rotate-180');
        }
    }
}

function navigateTo(path) {
    // Close mobile menu
    if (isMobileMenuOpen) {
        toggleMobileMenu();
    }
    
    // Close dropdowns
    hideFeaturesMenu();
    hideResourcesMenu();
    
    // Navigate to path (you can implement actual navigation here)
    console.log('Navigate to:', path);
    // For now, just show an alert
    alert(`Navigation to ${path} - This would normally navigate to the page`);
}

// Contact modal functionality - Global functions (exact copy from testimonials.html)
window.showContactModal = function() {
    console.log('showContactModal called');
    const modal = document.getElementById('contactModalOverlay');
    if (modal) {
        modal.classList.add('show');
        console.log('Modal should be visible now');
    } else {
        console.error('Contact modal not found');
    }
};

window.closeContactModal = function() {
    const modal = document.getElementById('contactModalOverlay');
    if (modal) {
        modal.classList.remove('show');
    }
};

// Login modal functionality - Global functions (exact copy from original PaymentFlow)
window.showLoginModal = function() {
    console.log('showLoginModal called');
    const modal = document.getElementById('loginModalOverlay');
    if (modal) {
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
        document.body.style.position = 'fixed';
        document.body.style.width = '100%';
        console.log('Login modal should be visible now');
    } else {
        console.error('Login modal not found');
    }
};

window.closeLoginModal = function() {
    const modal = document.getElementById('loginModalOverlay');
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = '';
        document.body.style.position = '';
        document.body.style.width = '';
    }
};

// Login form functions
window.toggleLoginPassword = function() {
    const passwordInput = document.getElementById('loginPassword');
    const eyeIcon = document.getElementById('loginEyeIcon');
    const eyeOffIcon = document.getElementById('loginEyeOffIcon');
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        eyeIcon.style.display = 'none';
        eyeOffIcon.style.display = 'block';
    } else {
        passwordInput.type = 'password';
        eyeIcon.style.display = 'block';
        eyeOffIcon.style.display = 'none';
    }
};

window.showLoginMessage = function(type, text) {
    const messageContent = document.getElementById('loginMessageContent');
    const messageContainer = document.getElementById('loginMessageContainer');
    
    messageContent.textContent = text;
    messageContent.className = `login-message-content ${type}`;
    messageContainer.className = `login-message-container ${type}`;
    messageContainer.style.display = 'block';
};

window.hideLoginMessage = function() {
    const messageContainer = document.getElementById('loginMessageContainer');
    messageContainer.style.display = 'none';
};

window.setLoginLoadingState = function(loading) {
    const submitButton = document.getElementById('loginSubmitButton');
    const googleButton = document.getElementById('loginGoogleButton');
    const submitText = document.getElementById('loginSubmitText');
    const loadingText = document.getElementById('loginLoadingText');
    
    submitButton.disabled = loading;
    googleButton.disabled = loading;
    
    if (loading) {
        submitText.style.display = 'none';
        loadingText.style.display = 'inline';
    } else {
        submitText.style.display = 'inline';
        loadingText.style.display = 'none';
    }
};

window.handleLoginSubmit = async function(event) {
    event.preventDefault();
    
    const email = document.getElementById('loginEmail').value.trim();
    const password = document.getElementById('loginPassword').value;

    if (!email || !password) {
        showLoginMessage('error', 'Veuillez remplir tous les champs.');
        return;
    }

    setLoginLoadingState(true);
    hideLoginMessage();

    try {
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // For demo purposes, simulate success
        showLoginMessage('success', 'Connexion réussie ! Redirection en cours...');
        
        // Redirect after success
        setTimeout(() => {
            window.location.href = 'dashboard.html';
        }, 1500);
        
    } catch (error) {
        showLoginMessage('error', error.message || 'Erreur lors de la connexion');
    } finally {
        setLoginLoadingState(false);
    }
};

window.handleGoogleLogin = async function() {
    setLoginLoadingState(true);
    hideLoginMessage();

    try {
        // Simulate Google OAuth
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        showLoginMessage('success', 'Connexion Google réussie ! Redirection en cours...');
    
        setTimeout(() => {
            window.location.href = 'dashboard.html';
        }, 1500);
        
    } catch (error) {
        showLoginMessage('error', error.message || 'Une erreur est survenue avec Google');
    } finally {
        setLoginLoadingState(false);
    }
};

window.resetContactForm = function() {
    document.getElementById('contactForm').style.display = 'block';
    document.getElementById('contactSuccess').style.display = 'none';
    document.getElementById('contactForm').reset();
};

window.showPrivacyPolicy = function() {
    document.getElementById('privacyModalOverlay').style.display = 'flex';
};

window.hidePrivacyPolicy = function() {
    document.getElementById('privacyModalOverlay').style.display = 'none';
};

window.handleContactSubmit = function(event) {
    event.preventDefault();
    
    // Hide any existing error
    hideError();
    
    // Get form data
    const formData = new FormData(event.target);
    const data = Object.fromEntries(formData);
    
    // Simple validation
    if (!data.name || !data.email || !data.subject || !data.message || !data.privacy) {
        showError('Veuillez remplir tous les champs obligatoires.');
        return;
    }
    
    // Show loading state
    setLoadingState(true);
    
    // Simulate form submission (replace with actual submission logic)
    setTimeout(() => {
        setLoadingState(false);
        document.getElementById('contactForm').style.display = 'none';
        document.getElementById('contactSuccess').style.display = 'block';
    }, 2000);
};

function showError(message) {
    const errorDiv = document.getElementById('contactError');
    const errorMessage = document.getElementById('contactErrorMessage');
    errorMessage.textContent = message;
    errorDiv.classList.add('show');
    
    // Hide error after 5 seconds
    setTimeout(() => {
        hideError();
    }, 5000);
}

function hideError() {
    const errorDiv = document.getElementById('contactError');
    if (errorDiv) {
        errorDiv.classList.remove('show');
    }
}

function setLoadingState(isLoading) {
    const submitBtn = document.getElementById('contactSubmitBtn');
    const spinner = document.getElementById('contactSubmitSpinner');
    const submitText = document.getElementById('contactSubmitText');
    
    if (isLoading) {
        submitBtn.disabled = true;
        spinner.style.display = 'block';
        submitText.textContent = 'Envoi en cours...';
    } else {
        submitBtn.disabled = false;
        spinner.style.display = 'none';
        submitText.textContent = 'Envoyer le message';
    }
}

// Add event listeners for modal closing (exact copy from testimonials.html)
document.addEventListener('DOMContentLoaded', function() {
    // Close modal when clicking outside
    const modal = document.getElementById('contactModalOverlay');
    if (modal) {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                closeContactModal();
            }
        });
    }
    
    // Close modal with close button
    const closeBtn = document.getElementById('closeContactBtn');
    if (closeBtn) {
        closeBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            closeContactModal();
        });
    }

    // Login modal event listeners
    const loginModal = document.getElementById('loginModalOverlay');
    if (loginModal) {
        loginModal.addEventListener('click', function(e) {
            if (e.target === this) {
                closeLoginModal();
            }
        });
    }
    
    // Close login modal with ESC key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            const loginModal = document.getElementById('loginModalOverlay');
            if (loginModal && loginModal.style.display === 'flex') {
                closeLoginModal();
            }
        }
    });
});



// Close dropdowns when clicking outside
document.addEventListener('click', function(event) {
    const featuresDropdown = document.getElementById('featuresDropdown');
    const resourcesDropdown = document.getElementById('resourcesDropdown');
    const featuresButton = document.querySelector('.nav-dropdown:first-child');
    const resourcesButton = document.querySelector('.nav-dropdown:last-child');
    
    // Close features dropdown if clicking outside
    if (featuresDropdown && !featuresButton.contains(event.target)) {
        hideFeaturesMenu();
    }
    
    // Close resources dropdown if clicking outside
    if (resourcesDropdown && !resourcesButton.contains(event.target)) {
        hideResourcesMenu();
    }
});

// Close mobile menu on scroll
window.addEventListener('scroll', function() {
    if (isMobileMenuOpen && window.innerWidth < 768) {
        toggleMobileMenu();
    }
});

// Handle ESC key
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        if (isMobileMenuOpen) {
            toggleMobileMenu();
        } else if (isFeaturesMenuOpen) {
            hideFeaturesMenu();
        } else if (isResourcesMenuOpen) {
            hideResourcesMenu();
        }
    }
});

// Export functions for global access
window.PaymentFlow = {
    showNotification,
    debounce,
    throttle,
    nextTestimonial,
    previousTestimonial,
    goToTestimonial,
    resetCache,
    nextUseCase,
    previousUseCase,
    nextMobileUseCase,
    previousMobileUseCase,
    showFeaturesMenu,
    hideFeaturesMenu,
    showResourcesMenu,
    hideResourcesMenu,
    toggleMobileMenu,
    toggleMobileFeaturesMenu,
    toggleMobileResourcesMenu,
    navigateTo,
    showContactModal,
    scrollToCalendly
};

// Calendly scroll function
function scrollToCalendly() {
    const calendlySection = document.querySelector('.calendly-container');
    if (calendlySection) {
        calendlySection.scrollIntoView({ behavior: 'smooth' });
    } else {
        window.location.hash = '#calendly';
    }
}

// Initialize Swiper for testimonials - Exact match to original PaymentFlow
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded, checking for Swiper...');
    console.log('Swiper available:', typeof Swiper !== 'undefined');
    
    // Wait for Swiper to load
    function initSwiper() {
        if (typeof Swiper !== 'undefined') {
            console.log('Initializing Swiper...');
            
            const testimonialsSwiper = new Swiper('.testimonials-swiper', {
                modules: [Swiper.Navigation, Swiper.Pagination],
                navigation: {
                    prevEl: '.testimonial-prev',
                    nextEl: '.testimonial-next',
                },
                spaceBetween: 30,
                pagination: {
                    el: '.swiper-pagination',
                    clickable: true,
                },
                slidesPerView: 1,
                centeredSlides: false,
                watchSlidesProgress: true,
                breakpoints: {
                    640: { slidesPerView: 1 },
                    768: { slidesPerView: 2 },
                    1024: { slidesPerView: 3 },
                },
                on: {
                    init: function () {
                        console.log('Swiper initialized successfully');
                        console.log('Navigation elements:', {
                            prev: this.navigation.prevEl,
                            next: this.navigation.nextEl
                        });
                        console.log('Pagination element:', this.pagination.el);
                        console.log('Pagination bullets:', this.pagination.bullets);
                    },
                    slideChange: function () {
                        console.log('Slide changed to:', this.activeIndex);
                        console.log('Is beginning:', this.isBeginning);
                        console.log('Is end:', this.isEnd);
                        console.log('Total slides:', this.slides.length);
                        console.log('Slides per group:', this.params.slidesPerGroup);
                    },
                    reachBeginning: function () {
                        console.log('Reached beginning - prev button should be disabled');
                    },
                    reachEnd: function () {
                        console.log('Reached end - next button should be disabled');
                    }
                }
            });
            
            // Store swiper instance globally for manual controls
            window.testimonialsSwiper = testimonialsSwiper;
            
            console.log('Swiper initialized:', testimonialsSwiper);
        } else {
            console.log('Swiper not ready, retrying...');
            setTimeout(initSwiper, 100);
        }
    }
    
    // Start initialization
    initSwiper();
});

// Manual click handlers for testimonials navigation
document.addEventListener('DOMContentLoaded', function() {
    // Wait a bit for elements to be ready
    setTimeout(() => {
        const prevBtn = document.querySelector('.testimonial-prev');
        const nextBtn = document.querySelector('.testimonial-next');
        
        if (prevBtn) {
            prevBtn.addEventListener('click', function(e) {
                e.preventDefault();
                console.log('Prev button clicked');
                if (window.testimonialsSwiper) {
                    window.testimonialsSwiper.slidePrev();
                }
            });
        }
        
        if (nextBtn) {
            nextBtn.addEventListener('click', function(e) {
                e.preventDefault();
                console.log('Next button clicked');
                if (window.testimonialsSwiper) {
                    window.testimonialsSwiper.slideNext();
                }
            });
        }
    }, 500);
});

// Global functions for onclick handlers (backup)
function testimonialPrev() {
    console.log('testimonialPrev() called');
    if (window.testimonialsSwiper) {
        // Check if we're at the beginning
        if (window.testimonialsSwiper.isBeginning) {
            console.log('Already at beginning, not moving');
            return;
        }
        window.testimonialsSwiper.slidePrev();
    } else {
        console.log('Swiper not available, trying alternative method');
        // Fallback: manual slide movement
        const swiperWrapper = document.querySelector('.testimonials-swiper .swiper-wrapper');
        if (swiperWrapper) {
            const currentTransform = swiperWrapper.style.transform || 'translate3d(0px, 0px, 0px)';
            const translateX = currentTransform.match(/translate3d\((-?\d+)px/);
            if (translateX) {
                const currentX = parseInt(translateX[1]);
                const newX = currentX + 300; // Move right by 300px
                swiperWrapper.style.transform = `translate3d(${newX}px, 0px, 0px)`;
                swiperWrapper.style.transition = 'transform 0.3s ease';
            }
        }
    }
}

function testimonialNext() {
    console.log('testimonialNext() called');
    if (window.testimonialsSwiper) {
        // Check if we're at the end
        if (window.testimonialsSwiper.isEnd) {
            console.log('Already at end, not moving');
            return;
        }
        window.testimonialsSwiper.slideNext();
    } else {
        console.log('Swiper not available, trying alternative method');
        // Fallback: manual slide movement
        const swiperWrapper = document.querySelector('.testimonials-swiper .swiper-wrapper');
        if (swiperWrapper) {
            const currentTransform = swiperWrapper.style.transform || 'translate3d(0px, 0px, 0px)';
            const translateX = currentTransform.match(/translate3d\((-?\d+)px/);
            if (translateX) {
                const currentX = parseInt(translateX[1]);
                const newX = currentX - 300; // Move left by 300px
                swiperWrapper.style.transform = `translate3d(${newX}px, 0px, 0px)`;
                swiperWrapper.style.transition = 'transform 0.3s ease';
            }
        }
    }
}

// Mobile Use Cases Swiper Initialization
document.addEventListener('DOMContentLoaded', function() {
    // Initialize mobile use cases swiper
    if (typeof Swiper !== 'undefined') {
        const mobileUseCasesSwiper = new Swiper('.mobile-use-cases-swiper', {
            modules: [Swiper.Pagination],
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
            spaceBetween: 0,
            slidesPerView: 1,
            loop: false,
            allowTouchMove: true,
        });
        
        console.log('Mobile use cases swiper initialized:', mobileUseCasesSwiper);
    }
});

// CRM Features Initialization
function initializeCRMFeatures() {
    // Initialize sector phrases animation
    initializeSectorPhrases();
    
    // Initialize scroll to demo function
    window.scrollToDemo = scrollToDemo;
}

// Sector Phrases Animation
function initializeSectorPhrases() {
    const sectorPhrases = [
        "Dans le BTP, 1 facture sur 3 est payée en retard. Avec Payment Flow, stop aux impayés.",
        "Artisan ? Concentrez-vous sur vos chantiers, on s'occupe des relances.",
        "Garagiste ? Accélérez vos encaissements et réduisez les oublis clients.",
        "Dans le soin, gardez l'esprit tranquille, Payment Flow veille sur vos paiements.",
        "Transporteur ? Automatisez vos relances et gagnez du temps administratif.",
        "Freelance ? Plus de stress, vos relances partent toutes seules.",
        "TPE/PME : DSO en baisse, trésorerie en hausse.",
        "Startup ? Concentrez-vous sur la croissance, nous gérons les relances."
    ];
    
    const sectorPhraseElement = document.getElementById('sectorPhrase');
    if (sectorPhraseElement) {
        let currentIndex = 0;
        
        // Update phrase every 3 seconds
        setInterval(() => {
            currentIndex = (currentIndex + 1) % sectorPhrases.length;
            sectorPhraseElement.textContent = sectorPhrases[currentIndex];
        }, 3000);
    }
}

// Scroll to Demo Function
function scrollToDemo() {
    const demoSection = document.getElementById('crm-demo-section');
    if (demoSection) {
        demoSection.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    }
}
