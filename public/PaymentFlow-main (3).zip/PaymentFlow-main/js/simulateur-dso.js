// Simulateur DSO JavaScript

// Default values
const defaultValues = {
    receivables: 120000,
    unpaidInvoices: 35,
    dso: 60,
    reminderHours: 12,
    reminderSuccessRate: 50,
    hourlyCost: 30,
};

// Calculate DSO results
function calculateResults(values) {
    const { receivables, dso, reminderHours, hourlyCost } = values;
    
    // Trésorerie immobilisée
    const lockedCash = receivables * (dso / 365);
    
    // Temps perdu (€/mois)
    const lostPerMonth = reminderHours * hourlyCost;

    // Avec Payment Flow
    const dsoOptimized = Math.round(dso * 0.6); // -40%
    const reminderHoursOptimized = Math.round(reminderHours * 0.25 * 10) / 10; // -75%
    const lockedCashOptimized = receivables * (dsoOptimized / 365);
    const lostPerMonthOptimized = reminderHoursOptimized * hourlyCost;

    return {
        lockedCash,
        lostPerMonth,
        dsoOptimized,
        reminderHoursOptimized,
        lockedCashOptimized,
        lostPerMonthOptimized,
        cashGain: lockedCash - lockedCashOptimized,
        timeGain: reminderHours - reminderHoursOptimized,
        euroGain: lostPerMonth - lostPerMonthOptimized,
    };
}

// Scroll to simulator function
function scrollToSimulator() {
    const simulator = document.getElementById('simulator');
    if (simulator) {
        simulator.scrollIntoView({ 
            behavior: 'smooth', 
            block: 'start' 
        });
    }
}

// Handle form submission
function handleSubmit(event) {
    event.preventDefault();
    
    // Get form values
    const values = {
        receivables: parseFloat(document.getElementById('receivables').value) || 0,
        unpaidInvoices: parseInt(document.getElementById('unpaidInvoices').value) || 0,
        dso: parseInt(document.getElementById('dso').value) || 0,
        reminderHours: parseFloat(document.getElementById('reminderHours').value) || 0,
        reminderSuccessRate: parseInt(document.getElementById('reminderSuccessRate').value) || 0,
        hourlyCost: parseFloat(document.getElementById('hourlyCost').value) || 0,
    };
    
    // Calculate results
    const results = calculateResults(values);
    
    // Update results display
    updateResultsDisplay(values, results);
    
    // Show results section
    showResults();
}

// Update results display
function updateResultsDisplay(values, results) {
    // Update current situation
    document.getElementById('currentDso').textContent = `${values.dso} jours`;
    document.getElementById('currentLockedCash').textContent = `${results.lockedCash.toLocaleString()} €`;
    document.getElementById('currentReminderHours').textContent = `${values.reminderHours} h`;
    
    // Update optimized situation
    document.getElementById('optimizedDso').textContent = `${results.dsoOptimized} jours`;
    document.getElementById('cashGain').textContent = `${results.cashGain.toLocaleString()} €`;
    document.getElementById('timeGain').textContent = `${results.timeGain} h`;
    
    // Update totals
    document.getElementById('totalCashGain').textContent = `${results.cashGain.toLocaleString()} €`;
    document.getElementById('totalTimeGain').textContent = `${results.timeGain} h/mois`;
}

// Show results section
function showResults() {
    const formSection = document.getElementById('simulatorForm');
    const resultsSection = document.getElementById('simulatorResults');
    
    if (formSection && resultsSection) {
        formSection.style.display = 'none';
        resultsSection.style.display = 'block';
        
        // Add animation
        resultsSection.style.animation = 'fadeInUp 0.7s ease-out';
    }
}

// Reset simulator
function resetSimulator() {
    const formSection = document.getElementById('simulatorForm');
    const resultsSection = document.getElementById('simulatorResults');
    
    if (formSection && resultsSection) {
        // Reset form values
        document.getElementById('receivables').value = defaultValues.receivables;
        document.getElementById('unpaidInvoices').value = defaultValues.unpaidInvoices;
        document.getElementById('dso').value = defaultValues.dso;
        document.getElementById('reminderHours').value = defaultValues.reminderHours;
        document.getElementById('reminderSuccessRate').value = defaultValues.reminderSuccessRate;
        document.getElementById('hourlyCost').value = defaultValues.hourlyCost;
        
        // Show form, hide results
        formSection.style.display = 'block';
        resultsSection.style.display = 'none';
    }
}

// Navigation functions
function showFeaturesMenu() {
    const dropdown = document.getElementById('featuresDropdown');
    const arrow = document.getElementById('featuresArrow');
    
    if (dropdown && arrow) {
        dropdown.style.display = 'block';
        dropdown.classList.add('show');
        arrow.style.transform = 'rotate(180deg)';
    }
}

function hideFeaturesMenu() {
    const dropdown = document.getElementById('featuresDropdown');
    const arrow = document.getElementById('featuresArrow');
    
    if (dropdown && arrow) {
        dropdown.classList.remove('show');
        setTimeout(() => {
            if (!dropdown.classList.contains('show')) {
                dropdown.style.display = 'none';
            }
        }, 200);
        arrow.style.transform = 'rotate(0deg)';
    }
}

function showResourcesMenu() {
    const dropdown = document.getElementById('resourcesDropdown');
    const arrow = document.getElementById('resourcesArrow');
    
    if (dropdown && arrow) {
        dropdown.style.display = 'block';
        dropdown.classList.add('show');
        arrow.style.transform = 'rotate(180deg)';
    }
}

function hideResourcesMenu() {
    const dropdown = document.getElementById('resourcesDropdown');
    const arrow = document.getElementById('resourcesArrow');
    
    if (dropdown && arrow) {
        dropdown.classList.remove('show');
        setTimeout(() => {
            if (!dropdown.classList.contains('show')) {
                dropdown.style.display = 'none';
            }
        }, 200);
        arrow.style.transform = 'rotate(0deg)';
    }
}

// Mobile menu functions
function toggleMobileMenu() {
    const mobileMenu = document.getElementById('mobileMenu');
    const mobileMenuIcon = document.getElementById('mobileMenuIcon');
    
    if (mobileMenu && mobileMenuIcon) {
        mobileMenu.classList.toggle('show');
        
        // Toggle icon between hamburger and X
        if (mobileMenu.classList.contains('show')) {
            mobileMenuIcon.innerHTML = `
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
            `;
        } else {
            mobileMenuIcon.innerHTML = `
                <line x1="4" y1="6" x2="20" y2="6"></line>
                <line x1="4" y1="12" x2="20" y2="12"></line>
                <line x1="4" y1="18" x2="20" y2="18"></line>
            `;
        }
    }
}

function toggleMobileFeaturesMenu() {
    const mobileMenu = document.getElementById('mobileFeaturesMenu');
    const mobileArrow = document.getElementById('mobileFeaturesArrow');
    
    if (mobileMenu && mobileArrow) {
        mobileMenu.classList.toggle('show');
        
        if (mobileMenu.classList.contains('show')) {
            mobileArrow.style.transform = 'rotate(180deg)';
        } else {
            mobileArrow.style.transform = 'rotate(0deg)';
        }
    }
}

function toggleMobileResourcesMenu() {
    const mobileMenu = document.getElementById('mobileResourcesMenu');
    const mobileArrow = document.getElementById('mobileResourcesArrow');
    
    if (mobileMenu && mobileArrow) {
        mobileMenu.classList.toggle('show');
        
        if (mobileMenu.classList.contains('show')) {
            mobileArrow.style.transform = 'rotate(180deg)';
        } else {
            mobileArrow.style.transform = 'rotate(0deg)';
        }
    }
}

// Contact modal functions
function showContactModal() {
    const modal = document.getElementById('contactModalOverlay');
    if (modal) {
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }
}

function closeContactModal() {
    const modal = document.getElementById('contactModalOverlay');
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
}

function showPrivacyPolicy() {
    const modal = document.getElementById('privacyModalOverlay');
    if (modal) {
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }
}

function closePrivacyPolicy() {
    const modal = document.getElementById('privacyModalOverlay');
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
}

// Handle contact form submission
function handleContactSubmit(event) {
    event.preventDefault();
    
    // Get form data
    const formData = new FormData(event.target);
    const data = Object.fromEntries(formData);
    
    // Basic validation
    if (!data.name || !data.email || !data.message || !data.consent) {
        alert('Veuillez remplir tous les champs obligatoires et accepter la politique de confidentialité.');
        return;
    }
    
    // Simulate form submission
    alert('Merci pour votre message ! Nous vous contacterons bientôt.');
    
    // Reset form
    event.target.reset();
    
    // Close modal
    closeContactModal();
}

// Initialize page
document.addEventListener('DOMContentLoaded', function() {
    // Set default values in form
    document.getElementById('receivables').value = defaultValues.receivables;
    document.getElementById('unpaidInvoices').value = defaultValues.unpaidInvoices;
    document.getElementById('dso').value = defaultValues.dso;
    document.getElementById('reminderHours').value = defaultValues.reminderHours;
    document.getElementById('reminderSuccessRate').value = defaultValues.reminderSuccessRate;
    document.getElementById('hourlyCost').value = defaultValues.hourlyCost;
    
    // Add click outside to close dropdowns
    document.addEventListener('click', function(event) {
        const featuresDropdown = document.getElementById('featuresDropdown');
        const resourcesDropdown = document.getElementById('resourcesDropdown');
        
        if (!event.target.closest('.nav-dropdown')) {
            if (featuresDropdown) {
                featuresDropdown.classList.remove('show');
                featuresDropdown.style.display = 'none';
                const arrow = document.getElementById('featuresArrow');
                if (arrow) arrow.style.transform = 'rotate(0deg)';
            }
            
            if (resourcesDropdown) {
                resourcesDropdown.classList.remove('show');
                resourcesDropdown.style.display = 'none';
                const arrow = document.getElementById('resourcesArrow');
                if (arrow) arrow.style.transform = 'rotate(0deg)';
            }
        }
    });
    
    // Add ESC key handler for modals
    document.addEventListener('keydown', function(event) {
        if (event.key === 'Escape') {
            closeContactModal();
            closePrivacyPolicy();
        }
    });
    
    // Add click outside to close modals
    document.addEventListener('click', function(event) {
        const contactModal = document.getElementById('contactModalOverlay');
        const privacyModal = document.getElementById('privacyModalOverlay');
        
        if (event.target === contactModal) {
            closeContactModal();
        }
        
        if (event.target === privacyModal) {
            closePrivacyPolicy();
        }
    });
});

// Navigation function
function navigateTo(path) {
    if (path === '/reporting-recouvrement') {
        window.location.href = 'reporting-recouvrement.html';
    } else if (path === '/crm') {
        window.location.href = 'crm.html';
    } else if (path === '/simulateur-dso') {
        window.location.href = 'simulateur-dso.html';
    } else if (path === '/personnalisation') {
        window.location.href = 'personnalisation.html';
    }
}

// Make functions globally available
window.scrollToSimulator = scrollToSimulator;
window.handleSubmit = handleSubmit;
window.resetSimulator = resetSimulator;
window.showFeaturesMenu = showFeaturesMenu;
window.hideFeaturesMenu = hideFeaturesMenu;
window.showResourcesMenu = showResourcesMenu;
window.hideResourcesMenu = hideResourcesMenu;
window.toggleMobileMenu = toggleMobileMenu;
window.toggleMobileFeaturesMenu = toggleMobileFeaturesMenu;
window.toggleMobileResourcesMenu = toggleMobileResourcesMenu;
window.showContactModal = showContactModal;
window.closeContactModal = closeContactModal;
window.showPrivacyPolicy = showPrivacyPolicy;
window.closePrivacyPolicy = closePrivacyPolicy;
window.handleContactSubmit = handleContactSubmit;
window.navigateTo = navigateTo;
